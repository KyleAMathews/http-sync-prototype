var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// client.ts
var client_exports = {};
__export(client_exports, {
  getShapeStream: () => getShapeStream
});
module.exports = __toCommonJS(client_exports);

// mod.js
if (typeof ReadableStream.prototype[Symbol.asyncIterator] !== "function") {
  ReadableStream.prototype[Symbol.asyncIterator] = async function* () {
    const reader = this.getReader();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done)
          return;
        yield value;
      }
    } finally {
      reader.releaseLock();
    }
  };
}
"\r".charCodeAt(0);
"\n".charCodeAt(0);
var TextDelimiterStream = class extends TransformStream {
  #buf = "";
  #delimiter;
  #inspectIndex = 0;
  #matchIndex = 0;
  #delimLPS;
  constructor(delimiter) {
    super({
      transform: (chunk5, controller7) => {
        this.#handle(chunk5, controller7);
      },
      flush: (controller8) => {
        controller8.enqueue(this.#buf);
      }
    });
    this.#delimiter = delimiter;
    this.#delimLPS = createLPS(new TextEncoder().encode(delimiter));
  }
  #handle(chunk6, controller9) {
    this.#buf += chunk6;
    let localIndex = 0;
    while (this.#inspectIndex < this.#buf.length) {
      if (chunk6[localIndex] === this.#delimiter[this.#matchIndex]) {
        this.#inspectIndex++;
        localIndex++;
        this.#matchIndex++;
        if (this.#matchIndex === this.#delimiter.length) {
          const matchEnd = this.#inspectIndex - this.#delimiter.length;
          const readyString = this.#buf.slice(0, matchEnd);
          controller9.enqueue(readyString);
          this.#buf = this.#buf.slice(this.#inspectIndex);
          this.#inspectIndex = 0;
          this.#matchIndex = 0;
        }
      } else {
        if (this.#matchIndex === 0) {
          this.#inspectIndex++;
          localIndex++;
        } else {
          this.#matchIndex = this.#delimLPS[this.#matchIndex - 1];
        }
      }
    }
  }
};
function createLPS(pat) {
  const lps = new Uint8Array(pat.length);
  lps[0] = 0;
  let prefixEnd = 0;
  let i = 1;
  while (i < lps.length) {
    if (pat[i] == pat[prefixEnd]) {
      prefixEnd++;
      lps[i] = prefixEnd;
      i++;
    } else if (prefixEnd === 0) {
      lps[i] = 0;
      i++;
    } else {
      prefixEnd = lps[prefixEnd - 1];
    }
  }
  return lps;
}
var JSONLinesParseStream = class {
  writable;
  readable;
  constructor({ separator = "\n", writableStrategy, readableStrategy } = {}) {
    const delimiterStream = new TextDelimiterStream(separator);
    const jsonParserStream = new TransformStream({
      transform: this.#separatorDelimitedJSONParser
    }, writableStrategy, readableStrategy);
    this.writable = delimiterStream.writable;
    this.readable = delimiterStream.readable.pipeThrough(jsonParserStream);
  }
  #separatorDelimitedJSONParser = (chunk, controller) => {
    if (!isBrankString(chunk)) {
      controller.enqueue(parse(chunk));
    }
  };
};
function parse(text) {
  try {
    return JSON.parse(text);
  } catch (error) {
    if (error instanceof Error) {
      const truncatedText = 30 < text.length ? `${text.slice(0, 30)}...` : text;
      throw new error.constructor(`${error.message} (parsing: '${truncatedText}')`);
    }
    throw error;
  }
}
var blank = new Set(" 	\r\n");
var branks = /[^ \t\r\n]/;
function isBrankString(str) {
  return !branks.test(str);
}
var JSONLinesStringifyStream = class extends TransformStream {
  constructor(options = {}) {
    const { separator = "\n", writableStrategy, readableStrategy } = options;
    const [prefix, suffix] = separator.includes("\n") ? [
      "",
      separator
    ] : [
      separator,
      "\n"
    ];
    super({
      transform(chunk, controller) {
        controller.enqueue(`${prefix}${JSON.stringify(chunk)}${suffix}`);
      }
    }, writableStrategy, readableStrategy);
  }
};

// client.ts
async function getShapeStream(shapeId, options) {
  const stream = new ReadableStream({
    async start(controller) {
      try {
        let lastLSN = 0;
        let upToDate = false;
        let initialUrl = `http://localhost:3000/shape/issues`;
        if (options.lsn) {
          initialUrl += `?lsn=${options.lsn}`;
        }
        await fetch(initialUrl, {
          signal: options.signal
        }).then(async ({ body }) => {
          const readable = body.pipeThrough(new TextDecoderStream()).pipeThrough(new JSONLinesParseStream());
          for await (const update of readable) {
            controller.enqueue(update);
            if (update.type === `data`) {
              lastLSN = update.lsn;
            }
          }
        });
        console.log(`done with initial fetch`);
        while (options.subscribe || !upToDate) {
          console.log({ lastLSN, upToDate, options: options.subscribe });
          await fetch(`http://localhost:3000/shape/issues?lsn=${lastLSN}`, {
            signal: options.signal
          }).then(async ({ body }) => {
            const readable = body.pipeThrough(new TextDecoderStream()).pipeThrough(new JSONLinesParseStream());
            for await (const update of readable) {
              controller.enqueue(update);
              if (update.type === `data`) {
                lastLSN = update.lsn;
              }
              if (update.type === `up-to-date`) {
                upToDate = true;
              }
            }
          });
        }
        controller.close();
      } catch (error) {
      }
    }
  });
  return stream;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getShapeStream
});
